<?php
	echo "Inhalt der Datei: kneipenhinzufuegen.inc.php";
	include("inc/checkuser.inc.php");
    echo "Test";
?>