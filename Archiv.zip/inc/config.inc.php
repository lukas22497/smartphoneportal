<?php
    $url="localhost";
    $user="mueller_olej";
    $pass="smartphoneportal";
    $dbName="smartphone_mueller_olej";
?>
